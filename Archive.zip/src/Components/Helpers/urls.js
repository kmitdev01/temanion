import {envVars} from './constants';
export const signupUrl = `${envVars.baseUrl}auth/sign_up`;
export const loginUrl = `${envVars.baseUrl}auth/sign_in`;
