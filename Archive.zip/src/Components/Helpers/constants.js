//import {BASE_URL} from 'react-native-dotenv';

export const envVars = {
    baseUrl: "https://staging.loyalbyte.my"
  };